package com.khoithuong.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.khoithuong.model.Employee;

@Repository
public class EmployeeDao {
	public List<Employee> getAllEmployees(SqlSession sqlSession){
		return sqlSession.selectList("mapper.Employee.selectAllEmployees");
	}
	
	public int addEmployee(SqlSession sqlSession, Employee employee){
		return sqlSession.insert("mapper.Employee.insertEmployee", employee);
	}
	
	public int deleteEmployee(SqlSession sqlSession, Long id){
		return sqlSession.delete("mapper.Employee.deleteEmployeeById", id);
	}
	
	public Employee getEmployeeById(SqlSession sqlSession, Long id){
		return sqlSession.selectOne("mapper.Employee.selectEmployeeById", id);
	}
	
	public int updateEmployeeById(SqlSession sqlSession, Employee employee){
		return sqlSession.update("mapper.Employee.updateEmployee", employee);
	}
}
