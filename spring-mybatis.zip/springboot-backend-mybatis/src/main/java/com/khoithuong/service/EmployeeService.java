package com.khoithuong.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.khoithuong.dao.EmployeeDao;
import com.khoithuong.model.Employee;


/**
 * The Class StudentService.
 */
@Service
public class EmployeeService extends BaseService{
	
	/** The student dao. */
	@Autowired
	private EmployeeDao employeeDao;
	
	
	/**
	 * Gets the all student.
	 *
	 * @return the all student
	 */
	public List<Employee> getStudentByPagination(){
		List<Employee> listEmployee = null;
		SqlSession sqlSession = null;
		try {		
			sqlSession= openSession();
			listEmployee = employeeDao.getAllEmployees(sqlSession);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			closeSession(sqlSession);
		}
		return listEmployee;
	}
	
	public int insertEmployee(Employee employee){
		int status = 0;
		SqlSession sqlSession = null;
		try {		
			sqlSession= openSession();
			status = employeeDao.addEmployee(sqlSession, employee);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			closeSession(sqlSession);
		}
		return status;
	}
	public int deleteEmployee(Long id){
		int status = 0;
		SqlSession sqlSession = null;
		try {		
			sqlSession= openSession();
			status = employeeDao.deleteEmployee(sqlSession, id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			closeSession(sqlSession);
		}
		return status;
	}
	
	public Employee getEmployeeById(Long id){
		Employee employee = null;
		SqlSession sqlSession = null;
		try {		
			sqlSession= openSession();
			employee = employeeDao.getEmployeeById(sqlSession, id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			closeSession(sqlSession);
		}
		return employee;
	}
	
	public int updateEmployeeById(Employee employee){
		int status = 0;
		SqlSession sqlSession = null;
		try {		
			sqlSession= openSession();
			status = employeeDao.updateEmployeeById(sqlSession, employee);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			closeSession(sqlSession);
		}
		return status;
	}
	
}
