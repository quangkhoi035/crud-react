package com.khoithuong.service;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * The Class BaseService.
 */
public abstract class BaseService {


  /** The SQL session factory. */
  @Autowired
  protected SqlSessionFactory sqlSessionFactory;

  protected void closeSession(SqlSession sqlSession) {
	    if (sqlSession != null) {
	      sqlSession.close();
	    }
	  }
  /**
   * Open session.
   *
   * @return the SQL session
   */
  protected SqlSession openSession() {
    SqlSession sqlSession = sqlSessionFactory.openSession();
    return sqlSession;
  }

  /**
   * Roll back session.
   *
   * @param sqlSession the SQL session
   */
  protected void rollBackSession(SqlSession sqlSession) {
    if (sqlSession != null) {
      sqlSession.rollback();
    }
  }
}
